/*
 * arithmetic.h
 *
 *  Created on: Jan 14, 2015
 *      Author: radoslav
 */

#ifndef ARITHMETIC_H_
#define ARITHMETIC_H_


int priority(char);
int ipow(int, int);


#endif /* ARITHMETIC_H_ */
